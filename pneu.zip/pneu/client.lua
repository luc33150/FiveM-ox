-- Script Côté Client
local notifiedVehicles = {}

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(500)  -- Check every half-second to reduce performance impact

        local ped = PlayerPedId()
        if IsPedInAnyVehicle(ped, false) then
            local vehicle = GetVehiclePedIsIn(ped, false)
            local vehicleId = NetworkGetNetworkIdFromEntity(vehicle)

            if not notifiedVehicles[vehicleId] then  -- Check if this vehicle has not been notified
                for tireIndex = 0, 7 do  -- Check all possible tires
                    if IsVehicleTyreBurst(vehicle, tireIndex, false) then
                        local message = "Attention : vous êtes entré dans un véhicule avec un pneu crevé."
                        TriggerEvent('ox_lib:notify', {
                            title = 'Alerte Véhicule',
                            description = message,
                            type = 'error',
                            position = 'top',
                            duration = 5000
                        })

                        -- Play sound multiple times
                        for i = 1, 3 do
                            PlaySoundFrontend(-1, "Out_Of_Bounds_Timer", "DLC_HEISTS_GENERAL_FRONTEND_SOUNDS", true)
                            Citizen.Wait(100)  -- Delay between sounds
                        end

                        notifiedVehicles[vehicleId] = true  -- Mark this vehicle as notified
                        break  -- Exit loop after notification
                    end
                end
            end
        else
            -- Reset the notified vehicles list when the player is not in a vehicle
            notifiedVehicles = {}
        end
    end
end)

-- Handle player exiting the vehicle
RegisterNetEvent('baseevents:leftVehicle')
AddEventHandler('baseevents:leftVehicle', function(vehicle, seat, displayName)
    local vehicleId = NetworkGetNetworkIdFromEntity(vehicle)
    if notifiedVehicles[vehicleId] then
        -- Effacer l'alerte ou arrêter toute action liée à l'alerte précédente
        -- Ici nous supposons que tu veux juste arrêter de montrer l'alerte si elle est encore affichée
        TriggerEvent('ox_lib:notify:stop')
        notifiedVehicles[vehicleId] = nil
    end
end)
